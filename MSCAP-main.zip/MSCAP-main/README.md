# MSCAP
MSCAP is an epigenetic clock based on multi-scale convolutional neural networks.
# Mlp-DDR
Mlp-DDR is a multilayer perceptron-based disease risk prediction model, which includes six additional models trained by machine learning methods.
